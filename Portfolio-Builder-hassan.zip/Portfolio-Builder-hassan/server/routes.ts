import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";
import multer from "multer";
import path from "path";
import fs from "fs";

const scryptAsync = promisify(scrypt);

// Configure multer for file uploads
const uploadDir = path.join(process.cwd(), "client", "public", "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage_config = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname));
  },
});

const upload = multer({ storage: storage_config });

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const derivedKey = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${salt}:${derivedKey.toString("hex")}`;
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  setupAuth(app);

  // === Upload Route ===
  app.post("/api/upload", upload.fields([{ name: 'images', maxCount: 10 }, { name: 'pdf', maxCount: 1 }]), (req: any, res) => {
    if (!req.isAuthenticated() || req.user.role !== 'admin') return res.sendStatus(401);
    
    const files = req.files;
    const response: any = { imageUrls: [], pdfUrl: null };
    
    if (files.images) {
      response.imageUrls = files.images.map((f: any) => `/uploads/${f.filename}`);
    }
    if (files.pdf) {
      response.pdfUrl = `/uploads/${files.pdf[0].filename}`;
    }
    
    res.json(response);
  });

  // === Projects ===
  app.get(api.projects.list.path, async (req, res) => {
    const projects = await storage.getProjects();
    res.json(projects);
  });

  app.post(api.projects.create.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== 'admin') return res.sendStatus(401);
    const data = api.projects.create.input.parse(req.body);
    const project = await storage.createProject(data);
    res.status(201).json(project);
  });

  app.patch(api.projects.update.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== 'admin') return res.sendStatus(401);
    const id = parseInt(req.params.id);
    const data = api.projects.update.input.parse(req.body);
    const project = await storage.updateProject(id, data);
    res.json(project);
  });

  app.delete(api.projects.delete.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== 'admin') return res.sendStatus(401);
    const id = parseInt(req.params.id);
    await storage.deleteProject(id);
    res.sendStatus(200);
  });

  // === Blog ===
  app.get(api.blog.list.path, async (req, res) => {
    const posts = await storage.getBlogPosts();
    res.json(posts);
  });

  app.get(api.blog.get.path, async (req, res) => {
    const post = await storage.getBlogPostBySlug(req.params.slug);
    if (!post) return res.status(404).json({ message: "Post not found" });
    res.json(post);
  });

  app.post(api.blog.create.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== 'admin') return res.sendStatus(401);
    const data = api.blog.create.input.parse(req.body);
    const post = await storage.createBlogPost({ ...data, authorId: req.user.id });
    res.status(201).json(post);
  });

  app.patch(api.blog.update.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== 'admin') return res.sendStatus(401);
    const id = parseInt(req.params.id);
    const data = api.blog.update.input.parse(req.body);
    const post = await storage.updateBlogPost(id, data);
    res.json(post);
  });

  app.delete(api.blog.delete.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== 'admin') return res.sendStatus(401);
    const id = parseInt(req.params.id);
    await storage.deleteBlogPost(id);
    res.sendStatus(200);
  });

  // === Contact ===
  app.post(api.contact.create.path, async (req, res) => {
    const data = api.contact.create.input.parse(req.body);
    const message = await storage.createContactMessage(data);
    res.status(201).json(message);
  });

  app.get(api.contact.list.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== 'admin') return res.sendStatus(401);
    const messages = await storage.getContactMessages();
    res.json(messages);
  });

  app.delete(api.contact.delete.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== 'admin') return res.sendStatus(401);
    const id = parseInt(req.params.id);
    await storage.deleteContactMessage(id);
    res.sendStatus(200);
  });

  // === Stats ===
  app.get(api.stats.get.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== 'admin') return res.sendStatus(401);
    const stats = await storage.getStats();
    res.json(stats);
  });

  // Seed Admin User
  const adminUser = await storage.getUserByUsername("admin");
  if (!adminUser) {
    const hashedPassword = await hashPassword("admin123");
    await storage.createUser({
      username: "admin",
      password: hashedPassword,
      role: "admin",
      name: "Hassan Tousif",
      email: "admin@example.com"
    });
    console.log("Admin user created: admin / admin123");
  }

  return httpServer;
}
