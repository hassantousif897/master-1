import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { HeroLoader } from "@/components/HeroLoader";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { ThemeProvider } from "next-themes";

import ProjectDetails from "@/pages/ProjectDetails";

// Pages
import Home from "@/pages/Home";
import Portfolio from "@/pages/Portfolio";
import About from "@/pages/About";
import Blog from "@/pages/Blog";
import BlogPost from "@/pages/BlogPost";
import Contact from "@/pages/Contact";
import Login from "@/pages/Login";
import AdminDashboard from "@/pages/admin/Dashboard";
import AdminProjects from "@/pages/admin/Projects";
import AdminBlog from "@/pages/admin/Blog";
import AdminMessages from "@/pages/admin/Messages";
import NotFound from "@/pages/not-found";

// Protected Route Component
function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  if (isLoading) {
    return <div className="h-screen flex items-center justify-center bg-black text-white"><Loader2 className="animate-spin w-8 h-8" /></div>;
  }

  if (!user || user.role !== 'admin') {
    // Redirect logic in effect is tricky inside render, so we return null and perform side-effect if we could, 
    // but here we just render Login or return null.
    // For simplicity in this generator:
    if (!user) {
        window.location.href = "/login"; // Force redirect
        return null;
    }
    return <div className="text-white pt-24 text-center">Unauthorized</div>;
  }

  return <Component />;
}

function Router() {
  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-primary selection:text-primary-foreground transition-colors duration-300">
      <Navigation />
      <Switch>
        {/* Public Routes */}
        <Route path="/" component={Home} />
        <Route path="/portfolio" component={Portfolio} />
        <Route path="/projects/:id" component={ProjectDetails} />
        <Route path="/about" component={About} />
        <Route path="/blog" component={Blog} />
        <Route path="/blog/:slug" component={BlogPost} />
        <Route path="/contact" component={Contact} />
        <Route path="/login" component={Login} />

        {/* Admin Routes */}
        <Route path="/admin">
          <ProtectedRoute component={AdminDashboard} />
        </Route>
        <Route path="/admin/projects">
          <ProtectedRoute component={AdminProjects} />
        </Route>
        <Route path="/admin/blog">
          <ProtectedRoute component={AdminBlog} />
        </Route>
        <Route path="/admin/messages">
          <ProtectedRoute component={AdminMessages} />
        </Route>

        <Route component={NotFound} />
      </Switch>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="dark">
      <QueryClientProvider client={queryClient}>
          <HeroLoader />
          <Router />
          <Toaster />
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
