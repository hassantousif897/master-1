import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Global Scroll Animation Observer
const initScrollAnimations = () => {
  const observerOptions = {
    root: null,
    rootMargin: "0px",
    threshold: 0.1,
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        // Trigger once
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  const observeElements = () => {
    document.querySelectorAll(".reveal-on-scroll").forEach((el) => {
      // Check if element is already in viewport or if it's the home page hero
      const rect = el.getBoundingClientRect();
      if (rect.top < window.innerHeight && rect.bottom > 0) {
        el.classList.add("is-visible");
      } else {
        observer.observe(el);
      }
    });
  };

  observeElements();

  // Re-observe when navigation happens (Wouter doesn't trigger full reload)
  // We'll use a MutationObserver to watch for content changes
  const contentObserver = new MutationObserver(() => {
    observeElements();
  });

  const rootElement = document.getElementById("root");
  if (rootElement) {
    contentObserver.observe(rootElement, { childList: true, subtree: true });
  }
};

// Use requestIdleCallback or setTimeout to initialize after initial render
setTimeout(initScrollAnimations, 100);

createRoot(document.getElementById("root")!).render(<App />);
