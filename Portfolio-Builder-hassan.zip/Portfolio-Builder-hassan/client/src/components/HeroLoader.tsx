import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export function HeroLoader() {
  const [isVisible, setIsVisible] = useState(true);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    const animationTimer = setTimeout(() => {
      setIsAnimating(true);
    }, 800);

    const visibilityTimer = setTimeout(() => {
      setIsVisible(false);
      document.body.style.overflow = "auto";
    }, 2500);

    document.body.style.overflow = "hidden";

    return () => {
      clearTimeout(animationTimer);
      clearTimeout(visibilityTimer);
      document.body.style.overflow = "auto";
    };
  }, []);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.section
          id="hero-loader"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="fixed inset-0 bg-[#0a0a0a] z-[9999] flex items-center justify-center overflow-hidden"
        >
          {/* Gates */}
          <motion.div
            initial={{ x: 0 }}
            animate={isAnimating ? { x: "-100%" } : { x: 0 }}
            transition={{ duration: 1.2, ease: [0.77, 0, 0.175, 1] }}
            style={{ 
              backgroundImage: 'url(/hero-gateway.jpg)',
              backgroundSize: '200% 100%',
              backgroundPosition: 'left center',
              backgroundRepeat: 'no-repeat'
            }}
            className="absolute top-0 left-0 w-1/2 h-full bg-[#111]"
          />
          <motion.div
            initial={{ x: 0 }}
            animate={isAnimating ? { x: "100%" } : { x: 0 }}
            transition={{ duration: 1.2, ease: [0.77, 0, 0.175, 1] }}
            style={{ 
              backgroundImage: 'url(/hero-gateway.jpg)',
              backgroundSize: '200% 100%',
              backgroundPosition: 'right center',
              backgroundRepeat: 'no-repeat'
            }}
            className="absolute top-0 right-0 w-1/2 h-full bg-[#111]"
          />

          {/* Loader Content */}
          <motion.div
            initial={{ opacity: 1, scale: 1 }}
            animate={isAnimating ? { opacity: 0, scale: 0.9 } : { opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            className="relative z-[10000] text-center"
          >
            <img 
              src="/favicon.png" 
              alt="Logo" 
              className="w-24 h-24 mx-auto mb-6 grayscale brightness-200"
            />
            <p className="text-white/60 tracking-[0.2em] uppercase text-sm font-light">
              Entering Portfolio
            </p>
            <div className="mt-4 w-12 h-[1px] bg-white/20 mx-auto" />
          </motion.div>
        </motion.section>
      )}
    </AnimatePresence>
  );
}
