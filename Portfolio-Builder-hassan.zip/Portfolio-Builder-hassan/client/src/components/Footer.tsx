import { Link, useLocation } from "wouter";

export function Footer() {
  const [location] = useLocation();
  if (location.startsWith("/admin")) return null;

  return (
    <footer className="py-24 px-6 md:px-12 border-t border-border bg-background transition-colors duration-300">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-end gap-12">
        <div>
          <h2 className="text-6xl md:text-8xl font-display font-bold text-muted transition-colors tracking-tighter">
            Let's create.
          </h2>
          <div className="mt-8 flex gap-6">
            <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">Twitter</a>
            <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">LinkedIn</a>
            <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">Instagram</a>
          </div>
        </div>

        <div className="text-muted-foreground text-sm">
          <p>&copy; {new Date().getFullYear()} Hassan Tousif. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
