import { Project } from "@shared/schema";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { FileText } from "lucide-react";

interface ProjectCardProps {
  project: Project;
  index: number;
}

export function ProjectCard({ project, index }: ProjectCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1, duration: 0.6 }}
      className="reveal-on-scroll reveal-fade-up"
    >
      <div className="group block space-y-4 card-zoom-container">
        <Link href={`/projects/${project.id}`} className="block cursor-pointer">
          <div className="aspect-[4/3] overflow-hidden rounded-sm bg-muted relative border border-border shadow-sm">
            {project.imageUrls && project.imageUrls.length > 0 ? (
              <img
                src={project.imageUrls[0]}
                alt={project.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-90 group-hover:opacity-100"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-card group-hover:bg-muted transition-colors">
                <span className="font-display text-4xl text-muted-foreground group-hover:text-foreground">{index + 1}</span>
              </div>
            )}
            <div className="absolute inset-0 bg-foreground/5 group-hover:bg-transparent transition-colors" />
          </div>
        </Link>
        
        <div className="flex justify-between items-start px-1">
          <Link href={`/projects/${project.id}`} className="flex-1 cursor-pointer">
            <div>
              <h3 className="text-2xl font-display font-medium text-foreground group-hover:text-muted-foreground transition-colors">
                {project.title}
              </h3>
              <p className="text-muted-foreground text-sm mt-1 uppercase tracking-wider">{project.category}</p>
            </div>
          </Link>
          <div className="flex gap-3 items-center">
            {project.pdfUrl && (
              <a 
                href={project.pdfUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-foreground transition-colors"
                title="View PDF"
              >
                <FileText className="w-5 h-5" />
              </a>
            )}
            <Link href={`/projects/${project.id}`}>
              <span className="text-muted-foreground group-hover:translate-x-1 transition-transform cursor-pointer hover:text-foreground">→</span>
            </Link>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
