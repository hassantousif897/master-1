import { useForm } from "react-hook-form";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Loader2 } from "lucide-react";

export default function Login() {
  const { login, isLoggingIn, user } = useAuth();
  const [, setLocation] = useLocation();
  const form = useForm({
    defaultValues: { username: "", password: "" },
  });

  if (user) {
    setLocation("/admin");
    return null;
  }

  const onSubmit = async (data: any) => {
    try {
      await login(data);
    } catch (e) {
      alert("Login failed");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-black">
      <div className="w-full max-w-md p-8 border border-white/10 rounded-lg bg-neutral-900/50">
        <h1 className="text-3xl font-display font-bold text-white mb-8 text-center">Admin Access</h1>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div>
            <label className="block text-sm text-neutral-400 mb-2">Username</label>
            <input
              {...form.register("username")}
              className="w-full bg-neutral-950 border border-neutral-800 rounded px-4 py-2 text-white focus:outline-none focus:border-white/50"
            />
          </div>
          <div>
            <label className="block text-sm text-neutral-400 mb-2">Password</label>
            <input
              type="password"
              {...form.register("password")}
              className="w-full bg-neutral-950 border border-neutral-800 rounded px-4 py-2 text-white focus:outline-none focus:border-white/50"
            />
          </div>
          <button
            type="submit"
            disabled={isLoggingIn}
            className="w-full bg-white text-black py-2 rounded font-medium hover:bg-neutral-200 transition-colors flex justify-center items-center"
          >
            {isLoggingIn ? <Loader2 className="animate-spin w-4 h-4" /> : "Enter"}
          </button>
        </form>
      </div>
    </div>
  );
}
