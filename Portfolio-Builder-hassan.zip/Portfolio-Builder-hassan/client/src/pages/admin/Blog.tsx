import { AdminLayout } from "@/components/AdminLayout";
import { useBlogPosts, useCreateBlogPost, useDeleteBlogPost, useUpdateBlogPost } from "@/hooks/use-blog";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Plus, Trash2, Edit2, Loader2 } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBlogPostSchema } from "@shared/schema";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";

type BlogFormData = z.infer<typeof insertBlogPostSchema>;

export default function AdminBlog() {
  const { data: posts, isLoading } = useBlogPosts();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);

  const createMutation = useCreateBlogPost();
  const updateMutation = useUpdateBlogPost();
  const deleteMutation = useDeleteBlogPost();
  const { toast } = useToast();

  const form = useForm<BlogFormData>({
    resolver: zodResolver(insertBlogPostSchema),
    defaultValues: { title: "", slug: "", content: "", excerpt: "", featuredImage: "", status: "draft" },
  });

  const onSubmit = async (data: BlogFormData) => {
    try {
      if (editingId) {
        await updateMutation.mutateAsync({ id: editingId, ...data });
        toast({ title: "Post updated" });
      } else {
        await createMutation.mutateAsync(data);
        toast({ title: "Post created" });
      }
      setIsDialogOpen(false);
      form.reset();
      setEditingId(null);
    } catch (e) {
      toast({ title: "Error", variant: "destructive" });
    }
  };

  const handleEdit = (post: any) => {
    setEditingId(post.id);
    form.reset({
      title: post.title,
      slug: post.slug,
      content: post.content,
      excerpt: post.excerpt,
      featuredImage: post.featuredImage,
      status: post.status as "draft" | "published"
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure?")) {
      await deleteMutation.mutateAsync(id);
      toast({ title: "Post deleted" });
    }
  };

  return (
    <AdminLayout>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-display font-bold">Blog Posts</h1>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => { setEditingId(null); form.reset(); }} className="bg-white text-black hover:bg-neutral-200">
              <Plus className="w-4 h-4 mr-2" /> New Post
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-neutral-900 border-white/10 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingId ? "Edit Post" : "New Post"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <input {...form.register("title")} placeholder="Title" className="w-full bg-black/50 border border-white/10 rounded p-2" />
              <input {...form.register("slug")} placeholder="Slug (url-friendly-name)" className="w-full bg-black/50 border border-white/10 rounded p-2" />
              <textarea {...form.register("excerpt")} placeholder="Excerpt" className="w-full bg-black/50 border border-white/10 rounded p-2 h-20" />
              <textarea {...form.register("content")} placeholder="Content (HTML supported for now)" className="w-full bg-black/50 border border-white/10 rounded p-2 h-64 font-mono" />
              <input {...form.register("featuredImage")} placeholder="Featured Image URL" className="w-full bg-black/50 border border-white/10 rounded p-2" />
              <select {...form.register("status")} className="w-full bg-black/50 border border-white/10 rounded p-2">
                <option value="draft">Draft</option>
                <option value="published">Published</option>
              </select>
              <Button type="submit" className="w-full bg-white text-black hover:bg-neutral-200" disabled={createMutation.isPending || updateMutation.isPending}>
                {createMutation.isPending || updateMutation.isPending ? <Loader2 className="animate-spin w-4 h-4" /> : (editingId ? "Update" : "Create")}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-4">
        {isLoading ? <div>Loading...</div> : posts?.map((post) => (
          <div key={post.id} className="flex justify-between items-center p-4 bg-neutral-900 border border-white/5 rounded-lg">
            <div>
              <h3 className="font-bold">{post.title}</h3>
              <div className="flex gap-2 text-sm text-neutral-500">
                <span className={post.status === 'published' ? 'text-green-500' : 'text-yellow-500'}>{post.status}</span>
                <span>•</span>
                <span>{post.slug}</span>
              </div>
            </div>
            <div className="flex gap-2">
              <Button size="icon" variant="ghost" onClick={() => handleEdit(post)}>
                <Edit2 className="w-4 h-4" />
              </Button>
              <Button size="icon" variant="ghost" className="text-red-500 hover:text-red-400" onClick={() => handleDelete(post.id)}>
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </AdminLayout>
  );
}
