import { AdminLayout } from "@/components/AdminLayout";
import { useStats } from "@/hooks/use-stats";
import { FolderKanban, FileText, MessageSquare } from "lucide-react";

export default function AdminDashboard() {
  const { data: stats } = useStats();

  const cards = [
    { label: "Projects", value: stats?.projects || 0, icon: FolderKanban },
    { label: "Blog Posts", value: stats?.posts || 0, icon: FileText },
    { label: "Messages", value: stats?.messages || 0, icon: MessageSquare },
  ];

  return (
    <AdminLayout>
      <h1 className="text-3xl font-display font-bold mb-8">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {cards.map((card) => (
          <div key={card.label} className="p-6 bg-neutral-900 border border-white/5 rounded-lg">
            <div className="flex justify-between items-start mb-4">
              <div className="p-2 bg-white/5 rounded-md text-white">
                <card.icon className="w-5 h-5" />
              </div>
            </div>
            <div className="text-3xl font-bold mb-1">{card.value}</div>
            <div className="text-sm text-neutral-500">{card.label}</div>
          </div>
        ))}
      </div>
    </AdminLayout>
  );
}
