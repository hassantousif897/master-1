import { AdminLayout } from "@/components/AdminLayout";
import { useProjects, useCreateProject, useDeleteProject, useUpdateProject } from "@/hooks/use-projects";
import { useState, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Plus, Trash2, Edit2, Loader2, Upload, FileText } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertProjectSchema } from "@shared/schema";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

type ProjectFormData = z.infer<typeof insertProjectSchema>;

export default function AdminProjects() {
  const { data: projects, isLoading } = useProjects();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);

  const imageInputRef = useRef<HTMLInputElement>(null);
  const pdfInputRef = useRef<HTMLInputElement>(null);

  const createMutation = useCreateProject();
  const updateMutation = useUpdateProject();
  const deleteMutation = useDeleteProject();
  const { toast } = useToast();

  const form = useForm<ProjectFormData>({
    resolver: zodResolver(insertProjectSchema),
    defaultValues: { title: "", description: "", category: "", imageUrls: [], pdfUrl: "", link: "", isVisible: true, sortOrder: 0 },
  });

  const onSubmit = async (data: ProjectFormData) => {
    try {
      const payload = { ...data, imageUrls };
      if (editingId) {
        await updateMutation.mutateAsync({ id: editingId, ...payload });
        toast({ title: "Project updated" });
      } else {
        await createMutation.mutateAsync(payload);
        toast({ title: "Project created" });
      }
      setIsDialogOpen(false);
      form.reset();
      setImageUrls([]);
      setEditingId(null);
    } catch (e) {
      toast({ title: "Error", variant: "destructive" });
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: 'image' | 'pdf') => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const formData = new FormData();
    if (type === 'image') {
      Array.from(files).forEach(file => formData.append('images', file));
    } else {
      formData.append('pdf', files[0]);
    }

    setIsUploading(true);
    try {
      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });
      
      if (!res.ok) throw new Error("Upload failed");
      
      const data = await res.json();
      if (type === 'image') {
        setImageUrls(prev => [...prev, ...(data.imageUrls || [])]);
        toast({ title: "Images uploaded successfully" });
      } else {
        form.setValue("pdfUrl", data.pdfUrl);
        toast({ title: "PDF uploaded successfully" });
      }
    } catch (error) {
      toast({ title: "Upload failed", variant: "destructive" });
    } finally {
      setIsUploading(false);
    }
  };

  const handleEdit = (project: any) => {
    setEditingId(project.id);
    setImageUrls(project.imageUrls || []);
    form.reset({
      title: project.title,
      description: project.description,
      category: project.category,
      imageUrls: project.imageUrls || [],
      pdfUrl: project.pdfUrl || "",
      link: project.link || "",
      isVisible: project.isVisible,
      sortOrder: project.sortOrder
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure?")) {
      await deleteMutation.mutateAsync(id);
      toast({ title: "Project deleted" });
    }
  };

  return (
    <AdminLayout>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-display font-bold">Projects</h1>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => { setEditingId(null); form.reset(); }} className="bg-white text-black hover:bg-neutral-200">
              <Plus className="w-4 h-4 mr-2" /> Add Project
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-neutral-900 border-white/10 text-white">
            <DialogHeader>
              <DialogTitle>{editingId ? "Edit Project" : "New Project"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <input {...form.register("title")} placeholder="Title" className="w-full bg-black/50 border border-white/10 rounded p-2" />
              <textarea {...form.register("description")} placeholder="Description" className="w-full bg-black/50 border border-white/10 rounded p-2" />
              <input {...form.register("category")} placeholder="Category" className="w-full bg-black/50 border border-white/10 rounded p-2" />
              
              <div className="space-y-2">
                <label className="text-sm text-neutral-400">Project Images</label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {imageUrls.map((url, i) => (
                    <div key={i} className="relative w-16 h-16 border border-white/10 rounded overflow-hidden group">
                      <img src={url} alt="" className="w-full h-full object-cover" />
                      <button 
                        type="button" 
                        onClick={() => setImageUrls(prev => prev.filter((_, j) => i !== j))}
                        className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </button>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <input type="file" accept="image/*" multiple className="hidden" ref={imageInputRef} onChange={(e) => handleFileUpload(e, 'image')} />
                  <Button type="button" variant="outline" className="w-full" onClick={() => imageInputRef.current?.click()} disabled={isUploading}>
                    <Upload className="w-4 h-4 mr-2" /> Upload Images
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm text-neutral-400">Project PDF (Optional)</label>
                <div className="flex gap-2">
                  <input {...form.register("pdfUrl")} placeholder="PDF URL" className="flex-1 bg-black/50 border border-white/10 rounded p-2" />
                  <input type="file" accept="application/pdf" className="hidden" ref={pdfInputRef} onChange={(e) => handleFileUpload(e, 'pdf')} />
                  <Button type="button" size="icon" variant="outline" onClick={() => pdfInputRef.current?.click()} disabled={isUploading}>
                    <FileText className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <input {...form.register("link")} placeholder="Live Demo Link" className="w-full bg-black/50 border border-white/10 rounded p-2" />
              <Button type="submit" className="w-full bg-white text-black hover:bg-neutral-200" disabled={createMutation.isPending || updateMutation.isPending || isUploading}>
                {createMutation.isPending || updateMutation.isPending ? <Loader2 className="animate-spin w-4 h-4" /> : (editingId ? "Update" : "Create")}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {isLoading ? <div>Loading...</div> : projects?.map((project) => (
          <div key={project.id} className="flex justify-between items-center p-4 bg-neutral-900 border border-white/5 rounded-lg">
            <div>
              <h3 className="font-bold">{project.title}</h3>
              <p className="text-sm text-neutral-500">{project.category}</p>
            </div>
            <div className="flex gap-2">
              <Button size="icon" variant="ghost" onClick={() => handleEdit(project)}>
                <Edit2 className="w-4 h-4" />
              </Button>
              <Button size="icon" variant="ghost" className="text-red-500 hover:text-red-400" onClick={() => handleDelete(project.id)}>
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </AdminLayout>
  );
}
