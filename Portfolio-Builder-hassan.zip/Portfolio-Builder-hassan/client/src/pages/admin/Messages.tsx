import { AdminLayout } from "@/components/AdminLayout";
import { useContactMessages, useDeleteContactMessage } from "@/hooks/use-contact";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

export default function AdminMessages() {
  const { data: messages, isLoading } = useContactMessages();
  const deleteMutation = useDeleteContactMessage();
  const { toast } = useToast();

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure?")) {
      await deleteMutation.mutateAsync(id);
      toast({ title: "Message deleted" });
    }
  };

  return (
    <AdminLayout>
      <h1 className="text-3xl font-display font-bold mb-8">Messages</h1>
      
      <div className="space-y-4">
        {isLoading ? <div>Loading...</div> : messages?.length === 0 ? <div className="text-neutral-500">No messages found.</div> : messages?.map((msg) => (
          <div key={msg.id} className="p-6 bg-neutral-900 border border-white/5 rounded-lg">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-bold text-lg">{msg.name}</h3>
                <p className="text-sm text-neutral-500">{msg.email}</p>
              </div>
              <div className="flex items-center gap-4">
                <span className="text-xs text-neutral-600">
                  {msg.createdAt && format(new Date(msg.createdAt), 'MMM dd, yyyy HH:mm')}
                </span>
                <Button size="icon" variant="ghost" className="text-red-500 hover:text-red-400 h-8 w-8" onClick={() => handleDelete(msg.id)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
            <p className="text-neutral-300 whitespace-pre-wrap">{msg.message}</p>
          </div>
        ))}
      </div>
    </AdminLayout>
  );
}
