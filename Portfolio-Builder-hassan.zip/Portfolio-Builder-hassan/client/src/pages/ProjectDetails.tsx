import { PageTransition } from "@/components/PageTransition";
import { useProjects } from "@/hooks/use-projects";
import { useParams, Link } from "wouter";
import { ChevronLeft, FileText, ExternalLink, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function ProjectDetails() {
  const { id } = useParams();
  const { data: projects, isLoading } = useProjects();
  const project = projects?.find((p) => p.id === Number(id));
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  if (isLoading) return <div className="h-screen flex items-center justify-center bg-background text-foreground transition-colors duration-300">Loading...</div>;
  if (!project) return <div className="h-screen flex items-center justify-center bg-background text-foreground text-center transition-colors duration-300">Project not found<br/><Link href="/portfolio" className="mt-4 text-muted-foreground hover:text-foreground transition-colors">Back to portfolio</Link></div>;

  const images = project.imageUrls || [];

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  return (
    <PageTransition>
      <div className="max-w-7xl mx-auto py-12 md:py-24 px-4 overflow-x-hidden bg-background transition-colors duration-300">
        <Link href="/portfolio" className="inline-flex items-center text-muted-foreground hover:text-foreground transition-colors mb-12">
          <ChevronLeft className="w-4 h-4 mr-2" /> Back to Portfolio
        </Link>

        <div className="flex flex-col space-y-12">
          {/* Top Section: Carousel */}
          {images.length > 0 && (
            <div className="relative aspect-[16/9] w-full group overflow-hidden rounded-sm bg-card border border-border shadow-2xl">
              <AnimatePresence mode="wait">
                <motion.img
                  key={currentImageIndex}
                  src={images[currentImageIndex]}
                  alt={`${project.title} detail ${currentImageIndex + 1}`}
                  initial={{ opacity: 0, x: 100 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -100 }}
                  transition={{ duration: 0.5, ease: "easeInOut" }}
                  className="w-full h-full object-cover"
                />
              </AnimatePresence>
              
              {images.length > 1 && (
                <>
                  <button
                    onClick={prevImage}
                    className="absolute left-4 top-1/2 -translate-y-1/2 p-2 bg-background/50 text-foreground rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-background/80 z-20"
                  >
                    <ChevronLeft className="w-6 h-6" />
                  </button>
                  <button
                    onClick={nextImage}
                    className="absolute right-4 top-1/2 -translate-y-1/2 p-2 bg-background/50 text-foreground rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-background/80 z-20"
                  >
                    <ChevronRight className="w-6 h-6" />
                  </button>
                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 z-20">
                    {images.map((_, i) => (
                      <div
                        key={i}
                        className={`w-2 h-2 rounded-full transition-colors ${
                          i === currentImageIndex ? "bg-foreground" : "bg-foreground/30"
                        }`}
                      />
                    ))}
                  </div>
                </>
              )}
            </div>
          )}

          {/* Bottom Section: Info & PDF */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
            <div className="lg:col-span-2 space-y-8">
              <div className="space-y-4">
                <span className="text-muted-foreground font-medium tracking-widest uppercase text-sm">{project.category}</span>
                <h1 className="text-5xl md:text-7xl font-display font-bold tracking-tighter text-foreground">{project.title}</h1>
              </div>

              <div className="max-w-none">
                <p className="text-muted-foreground text-xl leading-relaxed break-words overflow-wrap-anywhere whitespace-pre-line text-justify">
                  {project.description}
                </p>
              </div>

              <div className="flex flex-wrap gap-4 pt-4">
                {project.link && (
                  <Button asChild className="bg-foreground text-background hover:opacity-90 transition-opacity">
                    <a href={project.link} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="w-4 h-4 mr-2" /> Live Project
                    </a>
                  </Button>
                )}
                {project.pdfUrl && (
                  <Button variant="outline" asChild className="border-border text-foreground hover:bg-muted transition-colors">
                    <a href={project.pdfUrl} target="_blank" rel="noopener noreferrer">
                      <FileText className="w-4 h-4 mr-2" /> View Full PDF
                    </a>
                  </Button>
                )}
              </div>
            </div>

            {/* PDF Preview Sidebar */}
            {project.pdfUrl && (
              <div className="space-y-4">
                <h3 className="text-foreground font-display font-medium uppercase tracking-wider text-sm">PDF Document</h3>
                <a 
                  href={project.pdfUrl} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="block group relative aspect-[3/4] bg-card rounded-sm border border-border overflow-hidden shadow-lg"
                >
                  <div className="absolute inset-0 flex flex-col items-center justify-center space-y-4 z-10 bg-background/40 group-hover:bg-background/20 transition-colors">
                    <FileText className="w-12 h-12 text-foreground/50 group-hover:text-foreground transition-colors" />
                    <span className="text-xs text-foreground/70 group-hover:text-foreground uppercase tracking-widest">Click to Preview PDF</span>
                  </div>
                  <div className="w-full h-full bg-muted flex items-center justify-center opacity-50">
                    <div className="w-3/4 h-3/4 border border-border rounded-sm flex flex-col p-4 space-y-2">
                       <div className="h-2 w-full bg-foreground/10 rounded" />
                       <div className="h-2 w-2/3 bg-foreground/10 rounded" />
                       <div className="h-2 w-full bg-foreground/10 rounded" />
                       <div className="h-2 w-1/2 bg-foreground/10 rounded" />
                    </div>
                  </div>
                </a>
              </div>
            )}
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
