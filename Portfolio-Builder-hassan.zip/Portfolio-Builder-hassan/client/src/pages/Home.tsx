import { motion } from "framer-motion";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import { ProjectCard } from "@/components/ProjectCard";
import { useProjects } from "@/hooks/use-projects";
import aboutMeImg from "@/assets/profile.jpeg";
import heroBgImg from "@/assets/hero-bg.jpeg";

export default function Home() {
  const { data: projects, isLoading } = useProjects();
  const featuredProjects = projects?.slice(0, 4) || [];

  return (
    <div className="min-h-screen bg-background transition-colors duration-300">
      {/* Hero Section */}
      <section className="h-screen flex flex-col justify-center px-6 md:px-12 relative overflow-hidden bg-black">
        {/* Hero Background Image with Dark Wash */}
        <div 
          className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${heroBgImg})` }}
        >
          <div className="absolute inset-0 bg-black/60" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black" />
        </div>

        <div className="max-w-5xl z-10">
          <motion.h1 
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-6xl md:text-9xl font-display font-bold tracking-tighter text-white mb-6"
          >
            Hassan Tousif.
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="text-xl md:text-2xl text-neutral-400 font-light max-w-2xl leading-relaxed"
          >
            Digital Designer & Developer crafting cinematic web experiences. 
            Merging aesthetics with functionality.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="mt-12"
          >
            <Link href="/portfolio" className="inline-flex items-center gap-2 text-white border-b border-white pb-1 hover:text-neutral-300 hover:border-neutral-300 transition-colors">
              View Selected Work <ArrowRight className="w-4 h-4" />
            </Link>
          </motion.div>
        </div>

        {/* Ambient Background Element */}
        <div className="absolute right-0 top-1/4 w-[500px] h-[500px] bg-white/5 rounded-full blur-[120px] pointer-events-none" />
      </section>

      {/* Featured Work */}
      <section className="py-24 px-6 md:px-12 bg-background transition-colors duration-300 reveal-on-scroll reveal-fade-up">
        <div className="flex justify-between items-end mb-16">
          <h2 className="text-4xl md:text-5xl font-display font-medium text-foreground">Selected Works</h2>
          <Link href="/portfolio" className="hidden md:block text-muted-foreground hover:text-foreground transition-colors link-underline">
            All Projects
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-16">
          {isLoading ? (
             // Skeleton loading
             [1, 2].map(i => (
               <div key={i} className="animate-pulse space-y-4">
                 <div className="bg-muted aspect-[4/3] rounded-sm" />
                 <div className="h-6 bg-muted w-1/2 rounded" />
               </div>
             ))
          ) : (
            featuredProjects.map((project, idx) => (
              <ProjectCard key={project.id} project={project} index={idx} />
            ))
          )}
        </div>
      </section>

      {/* Intro/About Teaser */}
      <section className="py-48 px-6 md:px-12 flex justify-center bg-background transition-colors duration-300 relative overflow-hidden reveal-on-scroll reveal-fade-up">
        {/* Decorative element - Centered and refined */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-px h-32 bg-gradient-to-b from-transparent via-border to-transparent opacity-40" />
        
        <div className="max-w-3xl w-full text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="flex flex-col items-center"
          >
            <span className="text-xs uppercase tracking-[0.4em] text-muted-foreground mb-10 block font-bold opacity-60">Philosophy</span>
            <h2 className="text-4xl md:text-6xl font-display leading-[1.25] text-foreground mb-16 tracking-tight font-medium">
              "I believe in design that is not just <span className="italic">seen</span>, but <span className="text-muted-foreground/40">felt</span>. Creating digital environments that resonate with purpose and elegance."
            </h2>
            <Link href="/about" className="inline-flex items-center gap-4 group">
              <span className="px-10 py-4 rounded-full border border-border bg-card hover:bg-accent hover:text-accent-foreground transition-all duration-500 text-sm font-medium tracking-[0.2em] uppercase">
                More About Me
              </span>
            </Link>
          </motion.div>
        </div>

        {/* Subtle background text - Centered and stylized */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[12rem] md:text-[20rem] font-display font-bold text-foreground/[0.02] select-none pointer-events-none tracking-tighter leading-none italic whitespace-nowrap z-0">
          About
        </div>
      </section>
    </div>
  );
}
