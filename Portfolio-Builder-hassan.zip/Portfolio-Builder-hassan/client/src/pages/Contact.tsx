import { PageTransition } from "@/components/PageTransition";
import { useCreateContactMessage } from "@/hooks/use-contact";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { insertContactMessageSchema } from "@shared/schema";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const formSchema = insertContactMessageSchema;

export default function Contact() {
  const { toast } = useToast();
  const mutation = useCreateContactMessage();
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: { name: "", email: "", message: "" },
  });

  async function onSubmit(data: z.infer<typeof formSchema>) {
    try {
      await mutation.mutateAsync(data);
      toast({
        title: "Message sent",
        description: "I'll get back to you as soon as possible.",
      });
      form.reset();
    } catch (error) {
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    }
  }

  return (
    <PageTransition>
      <div className="max-w-4xl mx-auto py-12 md:py-24 px-4 bg-background transition-colors duration-300">
        <div className="grid md:grid-cols-2 gap-16">
          <div>
            <h1 className="text-5xl md:text-7xl font-display font-bold tracking-tighter mb-8 text-foreground">
              Contact.
            </h1>
            <p className="text-muted-foreground text-lg mb-8">
              Interested in working together? Drop me a line. I'm always open to discussing new projects, creative ideas or opportunities to be part of your visions.
            </p>
            <div className="text-foreground space-y-2 font-medium">
              <p>email@hassantousif.com</p>
              <p>+1 (555) 000-0000</p>
            </div>
          </div>

          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 mt-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground uppercase tracking-widest">Name</label>
              <input
                {...form.register("name")}
                className="w-full bg-transparent border-b border-border py-3 text-foreground focus:outline-none focus:border-foreground transition-colors"
                placeholder="Your name"
              />
              {form.formState.errors.name && (
                <p className="text-destructive text-sm">{form.formState.errors.name.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground uppercase tracking-widest">Email</label>
              <input
                {...form.register("email")}
                type="email"
                className="w-full bg-transparent border-b border-border py-3 text-foreground focus:outline-none focus:border-foreground transition-colors"
                placeholder="your@email.com"
              />
              {form.formState.errors.email && (
                <p className="text-destructive text-sm">{form.formState.errors.email.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground uppercase tracking-widest">Message</label>
              <textarea
                {...form.register("message")}
                rows={4}
                className="w-full bg-transparent border-b border-border py-3 text-foreground focus:outline-none focus:border-foreground transition-colors resize-none"
                placeholder="Tell me about your project"
              />
              {form.formState.errors.message && (
                <p className="text-destructive text-sm">{form.formState.errors.message.message}</p>
              )}
            </div>

            <button
              type="submit"
              disabled={mutation.isPending}
              className="px-8 py-3 bg-foreground text-background font-medium rounded-full hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center gap-2"
            >
              {mutation.isPending ? <Loader2 className="animate-spin w-4 h-4" /> : null}
              Send Message
            </button>
          </form>
        </div>
      </div>
    </PageTransition>
  );
}
