import { useRoute } from "wouter";
import { useBlogPost } from "@/hooks/use-blog";
import { PageTransition } from "@/components/PageTransition";
import { format } from "date-fns";
import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function BlogPost() {
  const [match, params] = useRoute("/blog/:slug");
  const slug = params?.slug || "";
  const { data: post, isLoading } = useBlogPost(slug);

  if (isLoading) return <div className="pt-32 text-center text-neutral-500">Loading...</div>;
  if (!post) return <div className="pt-32 text-center text-neutral-500">Post not found</div>;

  return (
    <PageTransition>
      <article className="max-w-3xl mx-auto py-12 md:py-24 px-4 bg-background transition-colors duration-300">
        <Link href="/blog" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-12 transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back to Journal
        </Link>
        
        <header className="mb-12">
          <h1 className="text-4xl md:text-6xl font-display font-bold text-foreground mb-6 leading-tight">
            {post.title}
          </h1>
          <div className="flex items-center gap-4 text-muted-foreground text-sm font-mono border-l-2 border-border pl-4">
            <time>{post.publishedAt ? format(new Date(post.publishedAt), 'MMMM dd, yyyy') : 'Unpublished'}</time>
            <span>•</span>
            <span>By Hassan Tousif</span>
          </div>
        </header>

        {post.featuredImage && (
          <div className="mb-12 aspect-video bg-card rounded-sm overflow-hidden border border-border">
            <img src={post.featuredImage} alt={post.title} className="w-full h-full object-cover" />
          </div>
        )}

        <div className="prose dark:prose-invert prose-lg max-w-none text-foreground/80 font-serif leading-loose">
          {/* In a real app, use a markdown renderer here. For now, we render raw text */}
          <div dangerouslySetInnerHTML={{ __html: post.content.replace(/\n/g, '<br/>') }} />
        </div>
      </article>
    </PageTransition>
  );
}
