import { PageTransition } from "@/components/PageTransition";
import { useBlogPosts } from "@/hooks/use-blog";
import { format } from "date-fns";
import { Link } from "wouter";

export default function Blog() {
  const { data: posts, isLoading } = useBlogPosts();
  // Filter for published posts only in real app, simplified here
  const publishedPosts = posts?.filter(p => p.status === 'published') || [];

  return (
    <PageTransition>
      <div className="max-w-4xl mx-auto py-12 md:py-24 px-4 bg-background transition-colors duration-300">
        <header className="mb-24">
          <h1 className="text-6xl md:text-8xl font-display font-bold tracking-tighter mb-6 text-foreground">Journal.</h1>
          <p className="text-muted-foreground text-xl max-w-xl">
            Thoughts on design, development, and life.
          </p>
        </header>

        <div className="space-y-12">
          {isLoading ? (
            <div className="text-muted-foreground">Loading entries...</div>
          ) : publishedPosts.length === 0 ? (
            <div className="text-muted-foreground">No entries found.</div>
          ) : (
            publishedPosts.map((post) => (
              <article key={post.id} className="group border-b border-border pb-12">
                <Link href={`/blog/${post.slug}`} className="block">
                  <div className="flex flex-col md:flex-row md:items-baseline justify-between gap-4 mb-4">
                    <h2 className="text-3xl font-display font-medium text-foreground group-hover:text-muted-foreground transition-colors">
                      {post.title}
                    </h2>
                    <time className="text-sm text-muted-foreground font-mono">
                      {post.publishedAt ? format(new Date(post.publishedAt), 'MMMM dd, yyyy') : 'Draft'}
                    </time>
                  </div>
                  <p className="text-muted-foreground max-w-2xl text-lg leading-relaxed">
                    {post.excerpt}
                  </p>
                  <span className="inline-block mt-6 text-sm text-foreground underline decoration-muted-foreground underline-offset-4 group-hover:decoration-foreground transition-all">
                    Read Article
                  </span>
                </Link>
              </article>
            ))
          )}
        </div>
      </div>
    </PageTransition>
  );
}
