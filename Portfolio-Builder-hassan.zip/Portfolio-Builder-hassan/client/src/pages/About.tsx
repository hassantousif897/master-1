import { PageTransition } from "@/components/PageTransition";
import { motion } from "framer-motion";
import aboutMeImg from "@/assets/profile.jpeg";

export default function About() {
  return (
    <PageTransition>
      <div className="max-w-5xl mx-auto py-12 md:py-24">
        <div className="grid md:grid-cols-2 gap-16 items-start">
          <div className="space-y-8 px-4">
            <h1 className="text-5xl md:text-7xl font-display font-bold tracking-tighter text-foreground">
              About Me.
            </h1>
            <div className="prose dark:prose-invert prose-lg text-muted-foreground">
              <p>
                Hello, I'm Hassan Tousif. I am a creative developer and designer based in the digital realm.
              </p>
              <p>
                My journey began with a curiosity for how things work on the web, which quickly evolved into a passion for creating immersive digital experiences. I specialize in building high-end websites that blend performance with storytelling.
              </p>
              <p>
                When I'm not coding, I'm exploring new design trends, photography, and the intersection of art and technology.
              </p>
            </div>
            
            <div className="pt-8">
              <h3 className="text-xl font-display text-foreground mb-4">Services</h3>
              <ul className="grid grid-cols-2 gap-4 text-muted-foreground">
                <li>Web Development</li>
                <li>UI/UX Design</li>
                <li>Brand Identity</li>
                <li>Technical Direction</li>
              </ul>
            </div>
          </div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="relative px-4"
          >
            <div className="aspect-[3/4] bg-card rounded-sm overflow-hidden relative border border-border group">
              <img 
                src={aboutMeImg} 
                alt="Hassan Tousif" 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/20 to-transparent" />
            </div>
            <div className="absolute -bottom-6 -left-2 w-[calc(100%-2rem)] h-full border border-border -z-10" />
          </motion.div>
        </div>
      </div>
    </PageTransition>
  );
}
