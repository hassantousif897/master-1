import { PageTransition } from "@/components/PageTransition";
import { ProjectCard } from "@/components/ProjectCard";
import { useProjects } from "@/hooks/use-projects";

export default function Portfolio() {
  const { data: projects, isLoading } = useProjects();

  return (
    <PageTransition>
      <div className="max-w-7xl mx-auto py-12 md:py-24 px-4 bg-background transition-colors duration-300">
        <header className="mb-24">
          <h1 className="text-6xl md:text-8xl font-display font-bold tracking-tighter mb-6 text-foreground">Work.</h1>
          <p className="text-muted-foreground text-xl max-w-xl">
            A selection of projects exploring web design, development, and brand identity.
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-20">
          {isLoading ? (
            <div className="text-foreground">Loading projects...</div>
          ) : projects?.length === 0 ? (
            <div className="text-muted-foreground">No projects yet.</div>
          ) : (
            projects?.map((project, idx) => (
              <ProjectCard key={project.id} project={project} index={idx} />
            ))
          )}
        </div>
      </div>
    </PageTransition>
  );
}
