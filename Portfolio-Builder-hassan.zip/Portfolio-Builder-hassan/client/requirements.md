## Packages
framer-motion | Essential for cinematic page transitions and scroll animations
date-fns | Formatting dates for blog posts and messages

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
