# Hassan Tousif Portfolio Website

## Overview

A personal portfolio website for Hassan Tousif featuring a cinematic, premium dark theme design. The application includes a public-facing portfolio with projects, blog, about, and contact pages, plus a complete admin panel for content management. Built with a React frontend and Express backend using PostgreSQL for data persistence.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **Routing**: Wouter for client-side routing (lightweight alternative to React Router)
- **Styling**: Tailwind CSS with a custom dark cinematic theme, using CSS variables for theming
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Animations**: Framer Motion for page transitions and scroll animations
- **State Management**: TanStack React Query for server state and caching
- **Forms**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful API with type-safe route definitions in `shared/routes.ts`
- **Authentication**: Passport.js with local strategy, session-based auth using express-session
- **Password Security**: scrypt hashing with timing-safe comparison
- **File Uploads**: Multer for handling image and PDF uploads

### Data Storage
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Location**: `shared/schema.ts` contains all table definitions
- **Migrations**: Drizzle Kit for schema migrations (`drizzle-kit push`)
- **Session Store**: connect-pg-simple for PostgreSQL session storage

### Project Structure
```
├── client/           # React frontend
│   ├── src/
│   │   ├── components/   # UI components including shadcn/ui
│   │   ├── pages/        # Route pages (Home, Portfolio, Blog, Admin)
│   │   ├── hooks/        # Custom hooks for API calls
│   │   └── lib/          # Utilities and query client
├── server/           # Express backend
│   ├── index.ts      # Entry point
│   ├── routes.ts     # API route handlers
│   ├── auth.ts       # Authentication setup
│   ├── storage.ts    # Database operations
│   └── db.ts         # Database connection
├── shared/           # Shared code between frontend/backend
│   ├── schema.ts     # Drizzle database schema
│   └── routes.ts     # API route type definitions
```

### Key Design Decisions

1. **Monorepo Structure**: Client and server share TypeScript types through the `shared/` directory, ensuring type safety across the stack.

2. **Storage Abstraction**: The `IStorage` interface in `storage.ts` abstracts database operations, making it easier to swap implementations.

3. **Role-Based Access**: Admin routes check `user.role === 'admin'` for authorization. Protected routes on frontend redirect unauthenticated users.

4. **Build Process**: Custom build script (`script/build.ts`) bundles the server with esbuild and client with Vite, outputting to `dist/`.

## External Dependencies

### Database
- **PostgreSQL**: Primary database, connection via `DATABASE_URL` environment variable
- **Drizzle ORM**: Type-safe database queries and schema management

### Authentication
- **Passport.js**: Authentication middleware
- **express-session**: Session management
- **connect-pg-simple**: PostgreSQL session store

### Frontend Libraries
- **Radix UI**: Accessible component primitives (dialogs, dropdowns, etc.)
- **TanStack React Query**: Data fetching and caching
- **Framer Motion**: Animation library
- **date-fns**: Date formatting for blog posts

### File Storage
- Files uploaded via Multer are stored in `client/public/uploads/` directory
- Served as static files by the Express server

### Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string (automatically provisioned via Replit)
- `SESSION_SECRET`: Secret for session encryption (defaults to fallback in development)

## Running the Application

### Development
- Run `npm run dev` to start the development server on port 5000
- The server handles both the API and frontend via Vite middleware

### Production
- Run `npm run build` to build the application
- Run `npm run start` to start the production server

### Database
- Run `npm run db:push` to push schema changes to the database

### Default Admin Credentials
- Username: `admin`
- Password: `admin123`